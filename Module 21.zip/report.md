# Module 21 Report: Alphabet Soup Charity Neural Network Model

## Overview of the Analysis

**Purpose**:  
The goal of this analysis is to develop a machine learning model that predicts the success of funding applications submitted to Alphabet Soup. The model should help the charity make data-driven decisions about which applications are more likely to achieve successful outcomes.

**Dataset Overview**:  
- The dataset contains details about funding applications, including the type of application, organizational affiliation, use case, income amount, and requested funding amount.  
- **Target**: Determine whether a funding application is successful (`IS_SUCCESSFUL`).

**Machine Learning Process**:  
1. Preprocessing the data by cleaning and encoding categorical variables.  
2. Creating and training a deep neural network model.  
3. Evaluating model performance.  

---

## Results

### Data Preprocessing

- **Target Variable**: `IS_SUCCESSFUL` (1 if the application is successful, 0 otherwise).  
- **Features**: All other columns after encoding, except the dropped `EIN` and `NAME` columns, which are non-informative.  
- **Removed Variables**: `EIN` and `NAME` were removed as they do not contribute to the prediction.  

### Compiling, Training, and Evaluating the Model

#### Neural Network Structure

- **Input Layer**:  
  - Number of features: 43

- **Hidden Layers**:  
  - **Layer 1**: 80 neurons with ReLU activation.  
  - **Layer 2**: 30 neurons with ReLU activation.  

- **Output Layer**:  
  - Single neuron with sigmoid activation to predict binary outcomes (`IS_SUCCESSFUL`).  

- **Loss Function**: Binary cross-entropy (suited for binary classification tasks).  
- **Optimizer**: Adam optimizer (effective for deep learning).  

#### Model Performance

- **Training Results**:  
  - Validation accuracy stabilized around **73.6%** after 100 epochs.  

- **Test Evaluation**:  
  - Accuracy: **72.6%**.  
  - Loss: **0.565**.  

#### Attempts to Improve Performance
1. Adjusted the hidden layer structure (number of neurons and layers).  
2. Normalized the data using `StandardScaler` to improve model convergence.  
3. Increased the number of epochs for better optimization.  
4. Used ReLU activation to address non-linear relationships in the data.
5. Added a third hidden layer  

---

## Summary

### Overall Results
The deep learning model achieved a test accuracy of **72.6%**, which suggests moderate predictive capability. While the performance is acceptable for initial evaluation, it leaves room for improvement.

### Recommendation for Improvement
- **Alternative Models**:  
  - **Random Forest Classifier** or **Gradient Boosting Machines** could be considered for potentially better performance. These models are well-suited for classification tasks with categorical data and may better capture complex relationships.  
  - Evaluate using additional metrics such as precision and recall to assess the model's ability to handle imbalanced data.

- **Justification**:  
  - Random Forest or Gradient Boosting models often outperform neural networks for structured/tabular data like this dataset.  
